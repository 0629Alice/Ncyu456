function myFunction(){
  let x=document.getElementById("numb").value;
  let text;
  if (isNaN(x)||x<1||x>10){
    text="輸入錯了";
  }else{
    text="你真棒"
  }
  document.getElementById("demo").innerHTML=text;
}